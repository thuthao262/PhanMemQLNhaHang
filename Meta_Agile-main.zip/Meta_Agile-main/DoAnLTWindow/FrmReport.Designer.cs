﻿namespace DoAnLTWindow
{
    partial class FrmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel3 = new System.Windows.Forms.Panel();
            label2 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            panel2 = new System.Windows.Forms.Panel();
            lbDate = new System.Windows.Forms.Label();
            lbStaff = new System.Windows.Forms.Label();
            lbTable = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            panel1 = new System.Windows.Forms.Panel();
            label12 = new System.Windows.Forms.Label();
            lbMoneyLeft = new System.Windows.Forms.Label();
            lbCustomMoney = new System.Windows.Forms.Label();
            lbTotal = new System.Windows.Forms.Label();
            lbCnt = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            lvReport = new System.Windows.Forms.ListView();
            STT = new System.Windows.Forms.ColumnHeader();
            Food = new System.Windows.Forms.ColumnHeader();
            Count = new System.Windows.Forms.ColumnHeader();
            Price = new System.Windows.Forms.ColumnHeader();
            Total = new System.Windows.Forms.ColumnHeader();
            Note = new System.Windows.Forms.ColumnHeader();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = System.Drawing.Color.Bisque;
            panel3.Controls.Add(label2);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(label3);
            panel3.Location = new System.Drawing.Point(0, 1);
            panel3.Name = "panel3";
            panel3.Size = new System.Drawing.Size(269, 135);
            panel3.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(70, 9);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(108, 23);
            label2.TabIndex = 2;
            label2.Text = "Nhà Hàng";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(12, 90);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(246, 18);
            label4.TabIndex = 4;
            label4.Text = "ĐC: 113 An Dương Vương, P4, Q5";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(57, 40);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(136, 36);
            label3.TabIndex = 3;
            label3.Text = "Gia Đình";
            // 
            // panel2
            // 
            panel2.BackColor = System.Drawing.Color.Bisque;
            panel2.Controls.Add(lbDate);
            panel2.Controls.Add(lbStaff);
            panel2.Controls.Add(lbTable);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label7);
            panel2.Location = new System.Drawing.Point(264, 1);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(283, 135);
            panel2.TabIndex = 12;
            // 
            // lbDate
            // 
            lbDate.AutoSize = true;
            lbDate.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbDate.Location = new System.Drawing.Point(103, 92);
            lbDate.Name = "lbDate";
            lbDate.Size = new System.Drawing.Size(24, 16);
            lbDate.TabIndex = 11;
            lbDate.Text = "Vũ";
            // 
            // lbStaff
            // 
            lbStaff.AutoSize = true;
            lbStaff.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbStaff.Location = new System.Drawing.Point(139, 62);
            lbStaff.Name = "lbStaff";
            lbStaff.Size = new System.Drawing.Size(24, 16);
            lbStaff.TabIndex = 10;
            lbStaff.Text = "Vũ";
            // 
            // lbTable
            // 
            lbTable.AutoSize = true;
            lbTable.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbTable.Location = new System.Drawing.Point(139, 35);
            lbTable.Name = "lbTable";
            lbTable.Size = new System.Drawing.Size(43, 16);
            lbTable.TabIndex = 9;
            lbTable.Text = "Bàn 1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(103, 9);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(88, 23);
            label5.TabIndex = 1;
            label5.Text = "Hoá Đơn";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label9.Location = new System.Drawing.Point(45, 90);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(47, 16);
            label9.TabIndex = 8;
            label9.Text = "Ngày:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(45, 35);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(56, 16);
            label6.TabIndex = 5;
            label6.Text = "Số Bàn:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(45, 62);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(79, 16);
            label7.TabIndex = 6;
            label7.Text = "Nhân Viên:";
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.Color.Bisque;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(lbMoneyLeft);
            panel1.Controls.Add(lbCustomMoney);
            panel1.Controls.Add(lbTotal);
            panel1.Controls.Add(lbCnt);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label1);
            panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            panel1.Location = new System.Drawing.Point(0, 174);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(547, 174);
            panel1.TabIndex = 11;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            label12.Location = new System.Drawing.Point(154, 137);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(230, 16);
            label12.TabIndex = 8;
            label12.Text = "Cảm Ơn Quí Khách Vì Đã Dùng Bữa";
            // 
            // lbMoneyLeft
            // 
            lbMoneyLeft.AutoSize = true;
            lbMoneyLeft.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbMoneyLeft.Location = new System.Drawing.Point(403, 101);
            lbMoneyLeft.Name = "lbMoneyLeft";
            lbMoneyLeft.Size = new System.Drawing.Size(16, 18);
            lbMoneyLeft.TabIndex = 7;
            lbMoneyLeft.Text = "0";
            // 
            // lbCustomMoney
            // 
            lbCustomMoney.AutoSize = true;
            lbCustomMoney.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbCustomMoney.Location = new System.Drawing.Point(403, 73);
            lbCustomMoney.Name = "lbCustomMoney";
            lbCustomMoney.Size = new System.Drawing.Size(16, 18);
            lbCustomMoney.TabIndex = 6;
            lbCustomMoney.Text = "0";
            // 
            // lbTotal
            // 
            lbTotal.AutoSize = true;
            lbTotal.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbTotal.Location = new System.Drawing.Point(403, 45);
            lbTotal.Name = "lbTotal";
            lbTotal.Size = new System.Drawing.Size(16, 18);
            lbTotal.TabIndex = 5;
            lbTotal.Text = "0";
            // 
            // lbCnt
            // 
            lbCnt.AutoSize = true;
            lbCnt.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbCnt.Location = new System.Drawing.Point(403, 17);
            lbCnt.Name = "lbCnt";
            lbCnt.Size = new System.Drawing.Size(16, 18);
            lbCnt.TabIndex = 4;
            lbCnt.Text = "0";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label11.Location = new System.Drawing.Point(265, 101);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(70, 18);
            label11.TabIndex = 3;
            label11.Text = "Tiền Dư:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label10.Location = new System.Drawing.Point(210, 73);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(127, 18);
            label10.TabIndex = 2;
            label10.Text = "Tiền Khách Đưa:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(250, 45);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(85, 18);
            label8.TabIndex = 1;
            label8.Text = "Tổng Tiền:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(210, 17);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(125, 18);
            label1.TabIndex = 0;
            label1.Text = "Tổng Số Lượng:";
            // 
            // lvReport
            // 
            lvReport.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { STT, Food, Count, Price, Total, Note });
            lvReport.GridLines = true;
            lvReport.HideSelection = false;
            lvReport.Location = new System.Drawing.Point(0, 133);
            lvReport.Name = "lvReport";
            lvReport.Scrollable = false;
            lvReport.Size = new System.Drawing.Size(547, 44);
            lvReport.TabIndex = 0;
            lvReport.UseCompatibleStateImageBehavior = false;
            lvReport.View = System.Windows.Forms.View.Details;
            // 
            // STT
            // 
            STT.Text = "STT";
            STT.Width = 30;
            // 
            // Food
            // 
            Food.Text = "Tên Món Ăn";
            Food.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            Food.Width = 150;
            // 
            // Count
            // 
            Count.Text = "Số Lượng";
            Count.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            Count.Width = 65;
            // 
            // Price
            // 
            Price.Text = "Đơn Giá";
            Price.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            Price.Width = 100;
            // 
            // Total
            // 
            Total.Text = "Tổng Tiền";
            Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            Total.Width = 140;
            // 
            // Note
            // 
            Note.Text = "Ghi Chú";
            Note.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FrmReport
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(547, 348);
            Controls.Add(lvReport);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "FrmReport";
            Text = "FrmReport";
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbDate;
        private System.Windows.Forms.Label lbStaff;
        private System.Windows.Forms.Label lbTable;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView lvReport;
        private System.Windows.Forms.ColumnHeader STT;
        private System.Windows.Forms.ColumnHeader Food;
        private System.Windows.Forms.ColumnHeader Count;
        private System.Windows.Forms.ColumnHeader Price;
        private System.Windows.Forms.ColumnHeader Total;
        private System.Windows.Forms.ColumnHeader Note;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbMoneyLeft;
        private System.Windows.Forms.Label lbCustomMoney;
        private System.Windows.Forms.Label lbTotal;
        private System.Windows.Forms.Label lbCnt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}